clear all
close all
clc

% O 1º passo que fiz, e quw achei necessario para rpservar alguams cores, foi passar de RGB para HSV. 
% Depois apliquei a binarizaçºao com imadjust e graythresh. Depois apliquei dilatação com disk e apliquei fill
tic

% Ler a imagem
img = imread('svpi2023_TP2_img_011_01.png');

% Converter de RGB para HSV
hsvImg = rgb2hsv(img);

% Binarização com imadjust e graythresh
binImg = imadjust(hsvImg(:,:,3));
threshold = graythresh(binImg);
binImg = imbinarize(binImg,threshold);

% Dilatação com disk
se = strel('disk',5);
dilatedImg = imdilate(binImg, se);

% Aplicar fill
filledImg = imfill(dilatedImg, 'holes');


CL = bwmorph(filledImg,'close');

[L, N] = bwlabel(CL);

stats = regionprops(L, "Circularity");
ff = [stats.Circularity];

trLim = 0.77;
cirLim = 0.93;
othrlim = 0.50;

triidx = find(ff < trLim & ff > othrlim);
ciridx = find(ff > cirLim);
squidx = find(ff > trLim & ff < cirLim);
otheridx = find(ff < othrlim);

TRI = ismember(L, triidx);
CIRC = ismember(L, ciridx);
SQUAD = ismember(L, squidx);
OTHER = ismember(L,otheridx);

toc

figure()
subplot(1,4,1), imshow(TRI); title('Triangles')
subplot(1,4,2), imshow(CIRC); title('Circles')
subplot(1,4,3), imshow(SQUAD); title('Squares')
subplot(1,4,4), imshow(OTHER); title('Other')


% Multiplicação lógica da imagem original com a máscara 
triImg = uint8(TRI) .* img;
ciriImg = uint8(CIRC) .* img;
squadImg = uint8(SQUAD) .* img;
otherImg = uint8(OTHER) .* img;

% Exibir a imagem original contendo apenas os SQUAD
figure()
subplot(1,4,1), imshow(triImg); title('Triangles')
subplot(1,4,2), imshow(ciriImg); title('Circles')
subplot(1,4,3), imshow(squadImg); title('Squares')
subplot(1,4,4), imshow(otherImg); title('Other')


% figure()
% imshow(edge(HSVBW,'log'))
% imshow(rgb2gray(HSV))

% Z = imbinarize(rgb2gray(imread('svpi2023_TP2_img_011_01.png')),'adaptive');
% Z = bwmorph(Z, 'open', 5);
% Z = edge(Z, 'log');
% figure()
% imshow(Z)